/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planernutricional;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 *
 * @author Lab
 */
public class main extends javax.swing.JFrame implements ActionListener { 
    
    // Definición de arreglos
    private List<JButton> botones = new ArrayList<>(), bCalorias, bProteinas, bCarbohidratos, bVitA, bVitC, bVitK, bFibra, bCalcio; // Con el fin de optimizar el destacamiento de botones los organizo en arreglos una vez inicie la aplicación
    private List<JProgressBar> barras;

    // Creo a conexion con la base de datos
    conectarBD conBD = new conectarBD();
    Connection conn = conBD.conexion();

    // Definicion de variables
    fraCrearUsuario crearUsuario;
    boolean darkMode = true;
    int periodo, periodoPrevio;

    public main() {
        // Establesco el modo oscuro de la ventana como el predeterminado
        setDarkMode();
        // Inicializo los componentes
        initComponents();
        // LLamo a metodos que crean los arreglos necesarios basados en los datos de la base de datos
        conBD.crearArrayAlimentos();
        conBD.crearArrayDatosNutricionales();
        conBD.crearArrayUsuarios();
        // LLamo a un metodo que junta todas las barras para una edicion mas facil y acotada
        crearArregloBarras();
        // Utilizando los datos del arreglo alimentos creo un boton para cado elemento y lo muestro en pantalla
        crearBoton();
        // Inicializo el combobox y configuro las barras para mostrar los balores indicados
        initComboboxUsuarios();
        initBarrasMetasNutricionales();
        // Ordeno los botones en arreglos especificos para optimizar el proceso de destacamiento cuando sea requerido
        ordenarBotonesEnArreglos();
        // Una vez los botones han sido creados modifico sus colores para que sean mas simples a la vista
        formatearColorBotones();

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panMain = new javax.swing.JPanel();
        panBoton = new javax.swing.JPanel();
        btnRun = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panAlimentos = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        barCaloria = new javax.swing.JProgressBar();
        barProteina = new javax.swing.JProgressBar();
        barVitaminaA = new javax.swing.JProgressBar();
        barCarbohidrato = new javax.swing.JProgressBar();
        barVitaminaC = new javax.swing.JProgressBar();
        barCalcio = new javax.swing.JProgressBar();
        barVitaminaK = new javax.swing.JProgressBar();
        barFibra = new javax.swing.JProgressBar();
        btnMostrarBotonesCalorias = new javax.swing.JButton();
        btnMostrarBotonesFibra = new javax.swing.JButton();
        btnMostrarBotonesVitK = new javax.swing.JButton();
        btnMostrarBotonesCalcio = new javax.swing.JButton();
        btnMostrarBotonesVitC = new javax.swing.JButton();
        btnMostrarBotonesCarbohidratos = new javax.swing.JButton();
        btnMostrarBotonesProteinas = new javax.swing.JButton();
        btnMostrarBotonesVitA = new javax.swing.JButton();
        btnReestablecerColoresBotones = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        cmbUsuarios = new javax.swing.JComboBox<>();
        btnRefrescar = new javax.swing.JButton();
        cboxLightMode = new javax.swing.JCheckBox();
        btnCrearUsuario = new javax.swing.JButton();
        lblDiasPorPeriodo = new javax.swing.JLabel();
        spnDiasPeriodo = new javax.swing.JSpinner();
        btnConfirmarDuracionPeriodo = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblUsuarios = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblAlimentos = new javax.swing.JTable();
        btnExportAlimentos = new javax.swing.JButton();
        btnImportAlimentos = new javax.swing.JButton();
        btnExportUsuario = new javax.swing.JButton();
        btnImportUsuarios = new javax.swing.JButton();

        jToggleButton1.setText("jToggleButton1");

        jScrollPane2.setViewportView(jEditorPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Planner Nutricional");
        setName("fraBase"); // NOI18N
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jTabbedPane1.setToolTipText("");
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(1280, 720));

        panMain.setPreferredSize(new java.awt.Dimension(1280, 720));
        panMain.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panBoton.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRun.setFont(new java.awt.Font("Krungthep", 1, 48)); // NOI18N
        btnRun.setText("TERMINAR DIA");
        btnRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRunActionPerformed(evt);
            }
        });
        panBoton.add(btnRun, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 0, 640, 120));

        btnClear.setFont(new java.awt.Font("Krungthep", 1, 48)); // NOI18N
        btnClear.setText("REINICIAR PERIODO");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        panBoton.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 120));

        panMain.add(panBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 540, 1280, 120));

        jScrollPane1.setBorder(null);

        panAlimentos.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Alimentos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 1, 24))); // NOI18N
        panAlimentos.setLayout(new java.awt.GridLayout(0, 5));
        jScrollPane1.setViewportView(panAlimentos);

        panMain.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 540));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nutrientes", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N

        barCaloria.setForeground(new java.awt.Color(0, 204, 204));
        barCaloria.setToolTipText("");
        barCaloria.setBorder(javax.swing.BorderFactory.createTitledBorder("Calorias"));

        barProteina.setForeground(new java.awt.Color(0, 204, 204));
        barProteina.setToolTipText("");
        barProteina.setBorder(javax.swing.BorderFactory.createTitledBorder("Proteinas"));

        barVitaminaA.setForeground(new java.awt.Color(0, 204, 204));
        barVitaminaA.setToolTipText("");
        barVitaminaA.setBorder(javax.swing.BorderFactory.createTitledBorder("Vitamina A"));

        barCarbohidrato.setForeground(new java.awt.Color(0, 204, 204));
        barCarbohidrato.setToolTipText("");
        barCarbohidrato.setBorder(javax.swing.BorderFactory.createTitledBorder("Carbohidratos"));

        barVitaminaC.setForeground(new java.awt.Color(0, 204, 204));
        barVitaminaC.setToolTipText("");
        barVitaminaC.setBorder(javax.swing.BorderFactory.createTitledBorder("Vitamina C"));

        barCalcio.setForeground(new java.awt.Color(0, 204, 204));
        barCalcio.setToolTipText("");
        barCalcio.setBorder(javax.swing.BorderFactory.createTitledBorder("Calcio"));

        barVitaminaK.setForeground(new java.awt.Color(0, 204, 204));
        barVitaminaK.setToolTipText("");
        barVitaminaK.setBorder(javax.swing.BorderFactory.createTitledBorder("Vitamina K"));

        barFibra.setForeground(new java.awt.Color(0, 204, 204));
        barFibra.setToolTipText("");
        barFibra.setBorder(javax.swing.BorderFactory.createTitledBorder("Fibra"));

        btnMostrarBotonesCalorias.setText("Destacar Alimentos");
        btnMostrarBotonesCalorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesCaloriasActionPerformed(evt);
            }
        });

        btnMostrarBotonesFibra.setText("Destacar Alimentos");
        btnMostrarBotonesFibra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesFibraActionPerformed(evt);
            }
        });

        btnMostrarBotonesVitK.setText("Destacar Alimentos");
        btnMostrarBotonesVitK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesVitKActionPerformed(evt);
            }
        });

        btnMostrarBotonesCalcio.setText("Destacar Alimentos");
        btnMostrarBotonesCalcio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesCalcioActionPerformed(evt);
            }
        });

        btnMostrarBotonesVitC.setText("Destacar Alimentos");
        btnMostrarBotonesVitC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesVitCActionPerformed(evt);
            }
        });

        btnMostrarBotonesCarbohidratos.setText("Destacar Alimentos");
        btnMostrarBotonesCarbohidratos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesCarbohidratosActionPerformed(evt);
            }
        });

        btnMostrarBotonesProteinas.setText("Destacar Alimentos");
        btnMostrarBotonesProteinas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesProteinasActionPerformed(evt);
            }
        });

        btnMostrarBotonesVitA.setText("Destacar Alimentos");
        btnMostrarBotonesVitA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarBotonesVitAActionPerformed(evt);
            }
        });

        btnReestablecerColoresBotones.setText("Reestablecer colores alimentos");
        btnReestablecerColoresBotones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReestablecerColoresBotonesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(barCalcio, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
                    .addComponent(barFibra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barVitaminaK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barVitaminaC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barVitaminaA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barCarbohidrato, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barProteina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(barCaloria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMostrarBotonesCalcio)
                    .addComponent(btnMostrarBotonesFibra)
                    .addComponent(btnMostrarBotonesVitK)
                    .addComponent(btnMostrarBotonesVitC)
                    .addComponent(btnMostrarBotonesCarbohidratos)
                    .addComponent(btnMostrarBotonesVitA)
                    .addComponent(btnMostrarBotonesProteinas)
                    .addComponent(btnMostrarBotonesCalorias))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btnReestablecerColoresBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnMostrarBotonesCalorias)
                    .addComponent(barCaloria, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(barProteina, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesProteinas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(barCarbohidrato, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesCarbohidratos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(barVitaminaA, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesVitA))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnMostrarBotonesVitC)
                    .addComponent(barVitaminaC, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(barVitaminaK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesVitK, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(barFibra, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesFibra, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(barCalcio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMostrarBotonesCalcio, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnReestablecerColoresBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panMain.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 140, 480, 400));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Configuracion", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 1, 24))); // NOI18N

        lblUsuario.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        lblUsuario.setText("Usuario:");

        cmbUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbUsuariosActionPerformed(evt);
            }
        });

        btnRefrescar.setText("Refrescar Usuarios");
        btnRefrescar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefrescarActionPerformed(evt);
            }
        });

        cboxLightMode.setText("Light Mode");
        cboxLightMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboxLightModeActionPerformed(evt);
            }
        });

        btnCrearUsuario.setText("Crear usuario");
        btnCrearUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearUsuarioActionPerformed(evt);
            }
        });

        lblDiasPorPeriodo.setText("Dias por periodo:");

        spnDiasPeriodo.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spnDiasPeriodoStateChanged(evt);
            }
        });

        btnConfirmarDuracionPeriodo.setText("Confirmar");
        btnConfirmarDuracionPeriodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarDuracionPeriodoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(lblUsuario)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cboxLightMode, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnRefrescar, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                            .addComponent(btnCrearUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(82, 82, 82))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lblDiasPorPeriodo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spnDiasPeriodo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConfirmarDuracionPeriodo)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnCrearUsuario))
                    .addComponent(lblUsuario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboxLightMode, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefrescar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDiasPorPeriodo)
                    .addComponent(spnDiasPeriodo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConfirmarDuracionPeriodo))
                .addGap(61, 61, 61))
        );

        panMain.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 0, 480, 150));

        jTabbedPane1.addTab("MAIN", panMain);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Usuarios");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Alimentos");

        tblUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tblUsuarios);

        tblAlimentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tblAlimentos);

        btnExportAlimentos.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnExportAlimentos.setText("Export");
        btnExportAlimentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportAlimentosActionPerformed(evt);
            }
        });

        btnImportAlimentos.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnImportAlimentos.setText("Import");
        btnImportAlimentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportAlimentosActionPerformed(evt);
            }
        });

        btnExportUsuario.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnExportUsuario.setText("Export");
        btnExportUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportUsuarioActionPerformed(evt);
            }
        });

        btnImportUsuarios.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnImportUsuarios.setText("Import");
        btnImportUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportUsuariosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(btnImportAlimentos)
                        .addGap(18, 18, 18)
                        .addComponent(btnExportAlimentos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 547, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnImportUsuarios)
                                .addGap(18, 18, 18)
                                .addComponent(btnExportUsuario))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(818, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnExportAlimentos)
                        .addComponent(btnImportAlimentos))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnImportUsuarios)
                        .addComponent(btnExportUsuario)))
                .addGap(0, 158, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(48, 48, 48)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(208, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("IMPORTAR / EXPORTAR BASES DE DATOS", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1303, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 706, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void restablecerValoresBarra() {
        // Reviso cada elemento en el arreglo barras y reestablezo su valor
        for (JProgressBar barra : barras) {
            barra.setValue(0);
        }
    }

    private void btnExportAlimentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportAlimentosActionPerformed
    }//GEN-LAST:event_btnExportAlimentosActionPerformed

    private void btnImportAlimentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportAlimentosActionPerformed
    }//GEN-LAST:event_btnImportAlimentosActionPerformed

    private void btnExportUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportUsuarioActionPerformed
    }//GEN-LAST:event_btnExportUsuarioActionPerformed

    private void btnImportUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportUsuariosActionPerformed
    }//GEN-LAST:event_btnImportUsuariosActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // Una vez termina el periodo señalado por el usuario, o, una vez este quiera resetear sus datos, reestablesco todos los valores y sus configuraciones para luego guardarlos en la base de datos
        formatearColorBotones();
        formatearColorBarra();
        restablecerValoresBarra();
        guardarDatosUsuario();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnRunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRunActionPerformed
        // Al finalizar el dia guardo los datos ingresados por el usuario, coloreo las barras dependiendo de su progreso para su meta, y le muestro feedback
        guardarDatosUsuario();
        colorearBarras();
        try {
            presentarFeedbackAlUsuario();
        }
        catch (SQLException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnRunActionPerformed

    private void btnMostrarBotonesCaloriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesCaloriasActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bCalorias);
    }//GEN-LAST:event_btnMostrarBotonesCaloriasActionPerformed

    private void btnMostrarBotonesFibraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesFibraActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bFibra);
    }//GEN-LAST:event_btnMostrarBotonesFibraActionPerformed

    private void btnMostrarBotonesVitKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesVitKActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bVitK);
    }//GEN-LAST:event_btnMostrarBotonesVitKActionPerformed

    private void btnMostrarBotonesCalcioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesCalcioActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bCalcio);
    }//GEN-LAST:event_btnMostrarBotonesCalcioActionPerformed

    private void btnMostrarBotonesVitCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesVitCActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bVitC);
    }//GEN-LAST:event_btnMostrarBotonesVitCActionPerformed

    private void btnMostrarBotonesCarbohidratosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesCarbohidratosActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bCarbohidratos);
    }//GEN-LAST:event_btnMostrarBotonesCarbohidratosActionPerformed

    private void btnMostrarBotonesProteinasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesProteinasActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bProteinas);
    }//GEN-LAST:event_btnMostrarBotonesProteinasActionPerformed

    private void btnMostrarBotonesVitAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarBotonesVitAActionPerformed
        // Formateo el estilo de los botones para que el usuario no se confunda
        formatearColorBotones();
        // Destaco los botones indicados para el usuario para que este pueda apreciar cuales aportan a su barra indicada
        colorearBotones(bVitA);
    }//GEN-LAST:event_btnMostrarBotonesVitAActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // Modifico la secuencia de salida en caso de que al usuario se le haya olvidado guardar
        
        // Guardo los datos en la BD
        guardarDatosUsuario();
        
        // Cierro el programa
        System.exit(0);
    }//GEN-LAST:event_formWindowClosing

    private void btnConfirmarDuracionPeriodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarDuracionPeriodoActionPerformed
        // Cambio el texto para avisarle al usuario que el cambio ha sido efectuado
        lblDiasPorPeriodo.setText("Dias por periodo:");
        
        // Le asigno valores a las variables previamente declaradas para que almacene el periodo nuevo y el antiguo
        periodoPrevio = periodo;
        periodo = (int) spnDiasPeriodo.getValue();
        
        // ***ELIMINAR ANTES DE ENTREGA***
        System.out.println(periodo);

        /* Multiplico las metas de las tablas por el resultado entre la division del periodo previo y el nuevo
           con el fin de aumentar o disminuir el periodo sin recurrir a operaciones complicadas*/ 
        float aux = ((float) periodo / (float) periodoPrevio);
        barras.forEach((barra) -> {
            barra.setMaximum(Math.round(barra.getValue() * aux));
        });
        
        /* ***ELIMINAR ANTES DE ENTREGA***
        for (Usuarios u : conBD.arregloUsuarios) {
        if (u.getId() == getSelectedUserID(0)) {
        u.setCalorias(Math.round(u.getCalorias() * aux));
        u.setProteinas(Math.round(u.getProteinas() * aux));
        u.setCarbohidratos(Math.round(u.getCarbohidratos() * aux));
        u.setVit_a(Math.round(u.getVit_a() * aux));
        u.setVit_c(Math.round(u.getVit_c() * aux));
        u.setVit_k(Math.round(u.getVit_k() * aux));
        u.setFibra(Math.round(u.getFibra() * aux));
        u.setCalcio(Math.round(u.getCalcio() * aux));
        }
        break;
        }*/
        
        // Actualizo las metas nutricionales en la tabla de datos
        try {
            PreparedStatement pst;
            pst = conn.prepareStatement("Update FROM nutritionValues (calorias, proteinas, carbohidratos, vit_a, vit_c, vit_k, fibra, calcio) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"); //Se pasa el codigo SQL de insercion al objeto PeparedStatement.
            for (int i = 1; i < 9; i++) {
                pst.setFloat(i, barras.get(i-1).getMaximum());
            }
            pst.executeUpdate();
            
            // Creo los arreglos nuevamente para reducir el riesgo de errores inesperados
            conBD.crearArrayDatosNutricionales();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_btnConfirmarDuracionPeriodoActionPerformed

    private void spnDiasPeriodoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spnDiasPeriodoStateChanged
        // Le indico al usuario que el valor del periodo no es efectivo porque es distinto al original
        // Util cuando el usuario esta cambiando la cantidad de dias
        lblDiasPorPeriodo.setText("Dias por periodo:*");
    }//GEN-LAST:event_spnDiasPeriodoStateChanged

    private void btnCrearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearUsuarioActionPerformed
        // Instancio un nuevo formulario que le permite al usuario crearse un perfil
        crearUsuario = new fraCrearUsuario();
        crearUsuario.setLocationRelativeTo(null);
        crearUsuario.setVisible(true);
    }//GEN-LAST:event_btnCrearUsuarioActionPerformed

    private void cboxLightModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboxLightModeActionPerformed
        // Dependiendo de si el usuario elige modo claro u oscuro cambio el estilo del formulario
        if (cboxLightMode.isSelected()) {
            setLightMode();
        }
        else {
            setDarkMode();
        }
        
        // Reestablesco el estilo de los botones para solucionar errores visuales
        formatearColorBotones();
    }//GEN-LAST:event_cboxLightModeActionPerformed

    private void btnRefrescarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefrescarActionPerformed
        // Refresco los valores y datos nutricionales para incluir a los nuevos usuarios
        conBD.crearArrayDatosNutricionales();
        conBD.crearArrayUsuarios();
        // Refresco los usuarios visibles en el comboBox
        initComboboxUsuarios();
    }//GEN-LAST:event_btnRefrescarActionPerformed

    private void cmbUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbUsuariosActionPerformed
        // Al combiar de perfil (o usuario) inicializo las barras nutricionales con los nuevos datos y obtengo la duracion del periodo
        initBarrasMetasNutricionales();
        periodo = conBD.arregloUsuarios.get(getSelectedUserID(1)).getPeriodo();
        spnDiasPeriodo.setValue((Object) periodo);
    }//GEN-LAST:event_cmbUsuariosActionPerformed

    private void btnReestablecerColoresBotonesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReestablecerColoresBotonesActionPerformed
        // Formateo el estilo de los botones
        formatearColorBotones();
    }//GEN-LAST:event_btnReestablecerColoresBotonesActionPerformed

    public static void main(String args[]) {
        /* Se crea y se muestra el formulario */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barCalcio;
    private javax.swing.JProgressBar barCaloria;
    private javax.swing.JProgressBar barCarbohidrato;
    private javax.swing.JProgressBar barFibra;
    private javax.swing.JProgressBar barProteina;
    private javax.swing.JProgressBar barVitaminaA;
    private javax.swing.JProgressBar barVitaminaC;
    private javax.swing.JProgressBar barVitaminaK;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnConfirmarDuracionPeriodo;
    private javax.swing.JButton btnCrearUsuario;
    private javax.swing.JButton btnExportAlimentos;
    private javax.swing.JButton btnExportUsuario;
    private javax.swing.JButton btnImportAlimentos;
    private javax.swing.JButton btnImportUsuarios;
    private javax.swing.JButton btnMostrarBotonesCalcio;
    private javax.swing.JButton btnMostrarBotonesCalorias;
    private javax.swing.JButton btnMostrarBotonesCarbohidratos;
    private javax.swing.JButton btnMostrarBotonesFibra;
    private javax.swing.JButton btnMostrarBotonesProteinas;
    private javax.swing.JButton btnMostrarBotonesVitA;
    private javax.swing.JButton btnMostrarBotonesVitC;
    private javax.swing.JButton btnMostrarBotonesVitK;
    private javax.swing.JButton btnReestablecerColoresBotones;
    private javax.swing.JButton btnRefrescar;
    private javax.swing.JButton btnRun;
    private javax.swing.JCheckBox cboxLightMode;
    private javax.swing.JComboBox<String> cmbUsuarios;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel lblDiasPorPeriodo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel panAlimentos;
    private javax.swing.JPanel panBoton;
    private javax.swing.JPanel panMain;
    private javax.swing.JSpinner spnDiasPeriodo;
    private javax.swing.JTable tblAlimentos;
    private javax.swing.JTable tblUsuarios;
    // End of variables declaration//GEN-END:variables

    private void crearBoton() {
        // Por cada alimento creo un boton con su nombre y lo muestro
        for (Alimentos a : conBD.arregloAlimentos) {
            // Obtengo el nombre del alimento y se lo asigno de nombre a un boton
            JButton boton = new JButton(a.getNombre());
            boton.addActionListener(this);
            // Añado el boton al panel y lo refresco una vez termine el for, ordenandolo en el proceso
            panAlimentos.add(boton);
            botones.add(boton);
        }
        panAlimentos.updateUI();
    }

    private void initComboboxUsuarios() {
        // Elimino todos los usuarios del combobox
        cmbUsuarios.removeAllItems();
        
        // Por cada usuario presente en el arreglo le agrego el nombre al combobox
        for (Usuarios u : conBD.arregloUsuarios) {
            cmbUsuarios.addItem(u.getNombre());
        }
        
        // Obtengo el periodo del usuario predeterminado
        periodo = conBD.arregloUsuarios.get(getSelectedUserID(1)).getPeriodo();
        spnDiasPeriodo.setValue((Object) periodo);
    }

    private void initBarrasMetasNutricionales() {
        // Obetengo el id del usuario seleccionado
        int id = getSelectedUserID(0);
        
        for (MetasNutricional mn : conBD.arregloMetasNutricionales) {
            if (mn.getId() == id) {
                // Convierto los float a int de la meta preservando las proporciones (no perdiendo datos) al multiplicar por (10*periodo)
                barCaloria.setMaximum((int) mn.getCalorias() * (10 * periodo));
                barProteina.setMaximum((int) mn.getProteinas() * (10 * periodo));
                barCarbohidrato.setMaximum((int) mn.getCarbohidratos() * (10 * periodo));
                barVitaminaA.setMaximum((int) mn.getVit_a() * (10 * periodo));
                barVitaminaC.setMaximum((int) mn.getVit_c() * (10 * periodo));
                barVitaminaK.setMaximum((int) mn.getVit_k() * (10 * periodo));
                barFibra.setMaximum((int) mn.getFibra() * (10 * periodo));
                barCalcio.setMaximum((int) mn.getCalcio() * (10 * periodo));
                
                // Convierto los float a int del progreso preservando las proporciones (no perdiendo datos) al multiplicar por (10*periodo)
                id = getSelectedUserID(1);
                barCaloria.setValue((int) conBD.arregloUsuarios.get(id).getCalorias());
                barProteina.setValue((int) conBD.arregloUsuarios.get(id).getProteinas());
                barCarbohidrato.setValue((int) conBD.arregloUsuarios.get(id).getCarbohidratos());
                barVitaminaA.setValue((int) conBD.arregloUsuarios.get(id).getVit_a());
                barVitaminaC.setValue((int) conBD.arregloUsuarios.get(id).getVit_c());
                barVitaminaK.setValue((int) conBD.arregloUsuarios.get(id).getVit_k());
                barFibra.setValue((int) conBD.arregloUsuarios.get(id).getFibra());
                barCalcio.setValue((int) conBD.arregloUsuarios.get(id).getCalcio());
            }
        }
    }

    private int getSelectedUserID(int mode) {
        int id = 0, i = 0;
        for (Usuarios u : conBD.arregloUsuarios) {
            if (u.getNombre() == cmbUsuarios.getSelectedItem()) {
                if (mode == 0) {
                    id = u.getId();
                }
                else {
                    id = i;
                }

            }
            i++;
        }

        return id;
    }

    private void agregarDatosABarra(String nombre) {
        for (Alimentos alimento : conBD.arregloAlimentos) {
            if (alimento.getNombre() == nombre) {
                barCaloria.setValue(barCaloria.getValue() + ((int) alimento.getCalorias() * (10 * periodo)));
                barProteina.setValue(barProteina.getValue() + ((int) alimento.getProteinas() * (10 * periodo)));
                barCarbohidrato.setValue(barCarbohidrato.getValue() + ((int) alimento.getCarbohidratos() * (10 * periodo)));
                barVitaminaA.setValue(barVitaminaA.getValue() + ((int) alimento.getVit_a() * (10 * periodo)));
                barVitaminaC.setValue(barVitaminaC.getValue() + ((int) alimento.getVit_c() * (10 * periodo)));
                barVitaminaK.setValue(barVitaminaK.getValue() + ((int) alimento.getVit_k() * (10 * periodo)));
                barFibra.setValue(barFibra.getValue() + ((int) alimento.getFibra() * (10 * periodo)));
                barCalcio.setValue(barCalcio.getValue() + ((int) alimento.getCalcio() * (10 * periodo)));
                break;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (botones.contains(e.getSource())) {
            String pos = botones.get(botones.indexOf(e.getSource())).getText();
            agregarDatosABarra(pos);
        }
    }

    private void guardarDatosUsuario() {
        try {
            // Se definen instrucciones para ejecutar las sentencias SQL
            PreparedStatement pst = conn.prepareStatement("UPDATE user set calorias = '" + barCaloria.getValue() + "',proteinas = '" + barProteina.getValue() + "',carbohidratos = '" + barCarbohidrato.getValue() + "',vit_a = '" + barVitaminaA.getValue() + "',vit_c = '" + barVitaminaC.getValue() + "',vit_k = '" + barVitaminaK.getValue() + "',fibra = '" + barFibra.getValue() + "',calcio = '" + barCalcio.getValue() + "' WHERE id = '" + getSelectedUserID(0) + "'"); //Se pasa el codigo SQL de insercion al objeto PeparedStatement.
            pst.executeUpdate();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("No se puede guardar");
        }
    }

    private void colorearBarras() {
        float progreso = 0;
        for (JProgressBar barra : barras) {
            progreso = (float) barra.getValue() / (float) barra.getMaximum();

            if (progreso <= 0.6) {
                barra.setForeground(Color.red);
            }
            else if (progreso < 0.9) {
                barra.setForeground(Color.orange);
            }
            else {
                barra.setForeground(Color.green);
            }
        }
    }

    private void crearArregloBarras() {
        barras = new ArrayList<>();
        
        barCaloria.setName("Calorias");
        barProteina.setName("Proteinas");
        barCarbohidrato.setName("Carbohidratos");
        barVitaminaA.setName("Vitamina A");
        barVitaminaC.setName("Vitamina C");
        barVitaminaK.setName("Vitamina K");
        barFibra.setName("Fibra");
        barCalcio.setName("Calcio");

        barras.add(barCaloria);
        barras.add(barProteina);
        barras.add(barCarbohidrato);
        barras.add(barVitaminaA);
        barras.add(barVitaminaC);
        barras.add(barVitaminaK);
        barras.add(barFibra);
        barras.add(barCalcio);
    }

    private void setDarkMode() {
        try {
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatDarkLaf");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        // Refresta Look and Feel del jFrame
        SwingUtilities.updateComponentTreeUI(this);
        this.pack();
        darkMode = true;
    }

    private void setLightMode() {
        try {
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        // Refresta Look and Feel del jFrame
        SwingUtilities.updateComponentTreeUI(this);
        this.pack();
        darkMode = false;
    }

    private void ordenarBotonesEnArreglos() {

        bCalorias = new ArrayList<>();
        bProteinas = new ArrayList<>();
        bCarbohidratos = new ArrayList<>();
        bVitA = new ArrayList<>();
        bVitC = new ArrayList<>();
        bVitK = new ArrayList<>();
        bFibra = new ArrayList<>();
        bCalcio = new ArrayList<>();

        int id = getSelectedUserID(1);
        float margen = (float) 0.1;

        for (JButton boton : botones) {
            for (Alimentos alimento : conBD.arregloAlimentos) {
                if (alimento.getNombre().equals(boton.getText())) {
                    // Si el aporte nutricional de un alimento es significativo entonces se agrega a unarreglo especial
                    if (alimento.getCalorias() / conBD.arregloMetasNutricionales.get(id).getCalorias() > margen) {
                        bCalorias.add(boton);
                    }
                    if (alimento.getProteinas() / conBD.arregloMetasNutricionales.get(id).getProteinas() > margen) {
                        bProteinas.add(boton);
                    }
                    if (alimento.getCarbohidratos() / conBD.arregloMetasNutricionales.get(id).getCarbohidratos() > margen) {
                        bCarbohidratos.add(boton);
                    }
                    if (alimento.getVit_a() / conBD.arregloMetasNutricionales.get(id).getVit_a() > margen) {
                        bVitA.add(boton);
                    }
                    if (alimento.getVit_c() / conBD.arregloMetasNutricionales.get(id).getVit_c() > margen) {
                        bVitC.add(boton);
                    }
                    if (alimento.getVit_k() / conBD.arregloMetasNutricionales.get(id).getVit_k() > margen) {
                        bVitK.add(boton);
                    }
                    if (alimento.getFibra() / conBD.arregloMetasNutricionales.get(id).getFibra() > margen) {
                        bFibra.add(boton);
                    }
                    if (alimento.getCalcio() / conBD.arregloMetasNutricionales.get(id).getCalcio() > margen) {
                        bCalcio.add(boton);
                    }
                    break;
                }
            }
        }
    }

    private void colorearBotones(List<JButton> arreglo) {
        for (JButton boton : arreglo) {

            if (darkMode) {
                boton.setForeground(Color.darkGray);
                boton.setBackground(Color.white);
            }
            else {
                boton.setBackground(Color.yellow);
                boton.setForeground(Color.darkGray);
            }
        }
    }

    private void formatearColorBotones() {
        for (JButton boton : botones) {
            if (!darkMode) {
                boton.setForeground(Color.darkGray);
                boton.setBackground(Color.white);
            }
            else {
                boton.setBackground(Color.darkGray);
                boton.setForeground(Color.white);
            }
        }
    }

    private void presentarFeedbackAlUsuario() throws SQLException {
        // Definicion de variables
        int opcion = 0;
        float progreso = 0;
        float[] diferencias = new float[8];
        String mensaje = "Progreso: \n";

        // Obtengo el progreso del usuario y se lo agrego al mensaje que luego le voy a mostrar
        for (JProgressBar barra : barras) {
            progreso = ((float) barra.getValue() / (float) barra.getMaximum()) * 100;
            mensaje += " > " + barra.getName() + ": " + Math.round(progreso) + "% \n";
        }

        // Le agrego una pregunta al final del mesaje respecto a si el usuario quiere agregar la diferencia a la proxima semana
        mensaje += "Desea agregar la diferencia nutricional a su proxima semana?";

        // Envio el mensaje y almaceno la respuesta
        opcion = JOptionPane.showConfirmDialog(null, mensaje, "Feedback semanal", 0);

        if (opcion == 1) {
            // El usuario no quiere que le agregue la diferencia
        }
        else {
            // Si el usuario quiere agregar la diferencia entonces la calculo
            for (int i = 0; i < 8; i++) {
                diferencias[i] = (barras.get(i).getMaximum() - barras.get(i).getValue()) / (10 * periodo);
            }
            // Creo la nueva meta nutricional
            crearUsuario = new fraCrearUsuario();
            crearUsuario.agregarFilaArregloMetasNutricionales(diferencias, getSelectedUserID(1));
        }

        // Restablesco valores tabla 
        formatearColorBotones();
        initBarrasMetasNutricionales(); // Inicio las tablas
        restablecerValoresBarra();
        guardarDatosUsuario();
    }

    private void formatearColorBarra() {
        for (JProgressBar barra : barras) {
            barra.setForeground(Color.cyan);
        }
    }
}
